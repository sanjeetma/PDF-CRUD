package com.example.pdfpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfUploadApplication.class, args);
	}

}
