package com.example.pdfpload.controller;

import java.io.FileNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.pdfpload.service.IPDFUploadService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/pdf")
public class PDFUploadController {

	@Autowired
	IPDFUploadService service;
	
	
	@PostMapping("/upload")
	String UplodPdf(@RequestBody MultipartFile file) {
		String status = "Not Uploaded ";
		try {
			status = service.uploadPdf(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	@DeleteMapping("/upload/{id}")
	String deletePdf(@PathVariable Long id) {
		return service.deletePdf(id);
	}
	
	@GetMapping("/view/{id}")
	void viewPdf(@PathVariable Long id,HttpServletResponse response) {
		 service.getPdf(id, response);
	}
	
	
	
}
