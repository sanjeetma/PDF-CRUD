package com.example.pdfpload.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.http.HttpHeaders;
import java.util.Optional;

import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.example.pdfpload.Entity.PDFUpload;
import com.example.pdfpload.Repository.PDFUploadRepo;

import jakarta.servlet.http.HttpServletResponse;

public class PDFUploadServiceImpl implements IPDFUploadService {

	
	@Autowired
	private PDFUploadRepo repo;
	
	
	@Override
	public String uploadPdf(MultipartFile file) throws FileNotFoundException {
		try {
		if(!file.isEmpty()) {
			PDFUpload pdf = new PDFUpload();
			pdf.setFileName(file.getOriginalFilename());
			pdf.setFileData(file.getBytes());
			repo.save(pdf);
		}else {
			return "File is Null";
		}
			
		
		}catch(Exception ex) {
			
		}
		return "pdf Uplod Successfully";
		
	}

	@Override
	public String deletePdf(Long Id) {
		Optional<PDFUpload> obj=repo.findById(Id);
		if(obj.isPresent()) {
			PDFUpload pdfUpload = obj.get();
			repo.deleteById(Id);
			return "File Deleted successfully";
			}
		return "File is not present";
	}

	@Override
	public void getPdf(Long Id,HttpServletResponse response) {
		Optional<PDFUpload> obj=repo.findById(Id);
		if(obj.isPresent()) {
			PDFUpload pdfUpload = obj.get();
			response.setContentType(MediaType.APPLICATION_PDF_VALUE);
			response.setHeader(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION, "attacchments;filename="
					+pdfUpload.getFileName());
			try {
				response.getOutputStream().write(pdfUpload.getFileData());
				response.getOutputStream().flush();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}else {
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		
	}
	

}
