package com.example.pdfpload.service;

import java.io.FileNotFoundException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public interface IPDFUploadService {

	
	String uploadPdf(MultipartFile file) throws FileNotFoundException;
	String deletePdf(Long Id);
	void getPdf(Long Id,HttpServletResponse response);
}
