package com.example.pdfpload.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pdfpload.Entity.PDFUpload;

public interface PDFUploadRepo extends JpaRepository<PDFUpload, Long> {

}
